<?php declare(strict_types=1);
use PHPUnit\Framework\TestCase;

final class phpunittest extends TestCase
{
    public function testCounselorCanView(): void
    {
        $this->assertTrue(TRUE);
    }
    public function testCounselorCanEdit(): void
    {
        $this->assertTrue(TRUE);
    }
    public function testCounselorCanDelete(): void
    {
        $this->assertTrue(TRUE);
    }
    public function testCounselorCanUpdate(): void
    {
        $this->assertTrue(TRUE);
    }
    public function testStudentCanView(): void
    {
        $this->assertTrue();
    }
    public function testStudentCanSelect(): void
    {
        $this->assertTrue(TRUE);
    }
    public function testStudentCanEdit(): void
    {
        $this->assertTrue(FALSE);
    }
}
